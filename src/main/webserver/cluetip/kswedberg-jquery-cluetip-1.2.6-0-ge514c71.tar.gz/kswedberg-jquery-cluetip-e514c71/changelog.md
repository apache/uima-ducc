
1.2.2 / 2011-09-01
==================

  * fix typo when checking indexOf; remove box-shadow inline style when dropShadow option is false or dropShadowSteps is 0.
  * only shift off heading of tipParts if opts.showTitle is true. fixes #55
  * trivial cleanup
